<DOCTYPE! html>
<html>
        <head>
            <title>MCE -  Admin</title>
            <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
            <link href="css/w3.css" rel="stylesheet" type="text/css">
            <link href="css/customs.css" rel="stylesheet" type="text/css">
            <script src="includes/ckeditor/ckeditor.js"></script>
        </head>
