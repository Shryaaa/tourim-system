# simple-hotel-tourism-site
This is a simple Hotel and Tourism project built in PHP.


To visit the AdminPanel, go to 'localhost/ht/admin'
    admin email: admin@admin.com
    Password: admin123
 Enjoy! :)
